<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>URL maker Tykayn</title>
		<link rel="stylesheet" media="screen" type="text/css" title="Mon design" href="design.css" />
		<link rel="shortcut icon" type="image/png" href="favicon.png" />
    </head>
    <body>
		<h1>Exemple de page pour faire un nouveau post de blog</h1>
		<textarea> coller ici de quoi bloguer</textarea>
		<input type="button" value="poster"/>
	    </body>
</html>
